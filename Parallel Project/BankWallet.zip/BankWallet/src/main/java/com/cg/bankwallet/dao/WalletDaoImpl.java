package com.cg.bankwallet.dao;

import java.text.DateFormat;


import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.bankwallet.bean.Account;
import com.cg.bankwallet.bean.Customer;
import com.cg.bankwallet.bean.Transaction;
import com.cg.bankwallet.exception.ZeroBalanceException;
import com.cg.bankwallet.utitility.StaticDb;

public class WalletDaoImpl implements IWalletDao {
	List<Transaction> transactions = new ArrayList<Transaction>();
	Transaction transaction, transaction2, transaction3;
	boolean result = false;
	int id = 0;

	@Override
	public Map<String, Integer> createAccount(Customer customer) {
		Map<String, Integer> createAccountMap = new HashMap<String, Integer>();
		customer.setCustomerId((int) (Math.random() * 10000));
		Account account = new Account((int) (Math.random() * 10000), 0);
		customer.setAccount(account);
		StaticDb.getCustomerDetails().put(customer.getCustomerId(), customer);
		createAccountMap.put("customerId", customer.getCustomerId());
		createAccountMap.put("accountNo", customer.getAccount().getAccountNo());
		return createAccountMap;
	}

	@Override
	public double showBalance(int customerId) {
		double balance = StaticDb.getCustomerDetails().get(customerId).getAccount().getBalance();
		return balance;
	}

	@Override
	public boolean deposit(int customerId, double amount) {
		result = false;
		double balance = showBalance(customerId);
		double preBalance = balance;
		balance = balance + amount;
		StaticDb.getCustomerDetails().get(customerId).getAccount().setBalance(balance);
		if (showBalance(customerId) > preBalance) {
			result = true;
			int transactionId = ++id;
			int toAccount = StaticDb.getCustomerDetails().get(customerId).getAccount().getAccountNo();
			Date date = Calendar.getInstance().getTime();
			DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");
			String strDate = dateFormat.format(date);
			transaction = new Transaction(transactionId, "Deposit", strDate, customerId, toAccount,
					Double.toString(amount));
			transactions.add(transaction);
		}
		return result;
	}

	@Override
	public boolean withdraw(int customerId, double amount) {
		result = false;
		double balance = 0;
		try{
			balance = showBalance(customerId);
			if(balance==0) {
				throw new ZeroBalanceException("account balance is zero...");
			}
		}
		catch (ZeroBalanceException e) {
			System.out.println(e.getMessage());
		}
		double preBalance = balance;
		balance = balance - amount;
		StaticDb.customerMap.get(customerId).getAccount().setBalance(balance);
		if (showBalance(customerId) < preBalance) {
			result = true;
			int transactionId = ++id;
			int toAccount = StaticDb.getCustomerDetails().get(customerId).getAccount().getAccountNo();
			Date date = Calendar.getInstance().getTime();
			DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");
			String strDate = dateFormat.format(date);
			transaction2 = new Transaction(transactionId, "Withdraw", strDate, customerId, toAccount,
					Double.toString(amount));
			transactions.add(transaction2);
		}
		return result;
	}

	@Override
	public boolean fundTransfer(int fromCustomerId, int toCustomerId, double amount) {
		result = false;
		double withdrawBalance = 0;
		try{
			 withdrawBalance = showBalance(fromCustomerId);
			if(withdrawBalance==0) {
				throw new ZeroBalanceException();
			}
		}
		catch (ZeroBalanceException e) {
			System.out.println(e.getMessage());
		}
		double preBalance = withdrawBalance;
		withdrawBalance = withdrawBalance - amount;
		StaticDb.customerMap.get(fromCustomerId).getAccount().setBalance(withdrawBalance);
		double transferBalance = showBalance(toCustomerId);
		double transferPreBalance = transferBalance;
		transferBalance = transferBalance + amount;
		StaticDb.getCustomerDetails().get(toCustomerId).getAccount().setBalance(transferBalance);
		if (showBalance(fromCustomerId) < preBalance && showBalance(toCustomerId) > transferPreBalance) {
			result = true;
			int transactionId = ++id;
			int toAccount = StaticDb.getCustomerDetails().get(toCustomerId).getAccount().getAccountNo();
			Date date = Calendar.getInstance().getTime();
			DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");
			String strDate = dateFormat.format(date);
			transaction3 = new Transaction(transactionId, "Fund Transfer", strDate, fromCustomerId, toAccount,
					Double.toString(amount));
			transactions.add(transaction3);
		}
		return result;
	}

	@Override
	public List<Transaction> printTransaction() {

		return transactions;
	}

	@Override
	public boolean validatePhone(String phone) {
		result = false;
		if (phone.matches("[0-9]+") && phone.length() == 10) {
			result = true;
		}
		return result;
	}

	@Override
	public boolean validateEmail(String email) {
		result = false;
		String emailRegEx = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
				+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
		Pattern pattern = Pattern.compile(emailRegEx);
		Matcher matcher = pattern.matcher(email);
		if (matcher.matches()) {
			result = true;
		}
		return result;
	}

	

	@Override
	public boolean validateCustomerId(int customerId) {
		result = false;
		for (int customerIds : StaticDb.getCustomerIds()) {
			if (customerId == customerIds) {
				result = true;
			}
		}
		return result;
	}



}
