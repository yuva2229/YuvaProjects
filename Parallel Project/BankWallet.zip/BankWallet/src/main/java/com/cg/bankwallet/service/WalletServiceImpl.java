package com.cg.bankwallet.service;

import java.util.List;
import java.util.Map;

import com.cg.bankwallet.bean.Customer;
import com.cg.bankwallet.bean.Transaction;
import com.cg.bankwallet.dao.IWalletDao;
import com.cg.bankwallet.dao.WalletDaoImpl;

public class WalletServiceImpl implements IWalletService {

	IWalletDao dao = new WalletDaoImpl();

	@Override
	public Map<String, Integer> createAccount(Customer customer) {
		return dao.createAccount(customer);
	}

	@Override
	public double showBalance(int customerId) {
		return dao.showBalance(customerId);
	}

	@Override
	public boolean deposit(int customerId, double amount) {
		return dao.deposit(customerId, amount);
	}

	@Override
	public boolean withdraw(int customerId, double amount) {
		return dao.withdraw(customerId, amount);
	}

	@Override
	public boolean fundTransfer(int fromCustomerId, int toCustomerId, double amount) {
		return dao.fundTransfer(fromCustomerId, toCustomerId, amount);
	}

	@Override
	public List<Transaction> printTransaction() {
		return dao.printTransaction();
	}

	@Override
	public boolean validatePhone(String phone) {
		return dao.validatePhone(phone);
	}

	@Override
	public boolean validateEmail(String email) {
		return dao.validateEmail(email);
	}

	
	@Override
	public boolean validateCustomerId(int customerId) {
		return dao.validateCustomerId(customerId);
	}

	

}
