package com.cg.bankwallet.ui;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.cg.bankwallet.bean.Customer;
import com.cg.bankwallet.bean.Transaction;
import com.cg.bankwallet.exception.NegativeAmountException;
import com.cg.bankwallet.service.IWalletService;
import com.cg.bankwallet.service.WalletServiceImpl;
import com.cg.bankwallet.utitility.StaticDb;

public class Client {

	public static void main(String[] args) {
		IWalletService service = new WalletServiceImpl();
		Scanner scanner = new Scanner(System.in);
		Scanner scanner2 = new Scanner(System.in);
		boolean result = false;
		int option = 0;
		do {
			System.out.println("\n1.Create Account\n2.Exit");
			System.out.println("Enter the option");
			try {
				option = scanner.nextInt();
			} catch (InputMismatchException e1) {
				System.out.println("Enter only digits");
			}
			switch (option) {
			case 1: {
				System.out.print("Enter Name: ");
				String customerName = scanner2.nextLine().trim();
				System.out.print("\nEnter Date of Birth in dd-mm-yyyy format: ");
				String date = scanner.next().trim();
				String phone = "";
				do {
					System.out.print("\nEnter the phone number: ");
					phone = scanner.next().trim();
					result = service.validatePhone(phone);
					if (result == false) {
						System.out.print("\nPhone number should contain only 10 digits ");
					}
				} while (result != true);
				System.out.print("\nEnter the Email: ");
				String email = "";
				do {
					email = scanner.next().trim();
					result = service.validateEmail(email);
					if (result == false) {
						System.out.print("\nEnter valid email address");
					}
				} while (result != true);
				System.out.print("\nEnter the Complete address: ");
				String address = scanner2.nextLine().trim();
				Customer customer = new Customer(customerName, date, phone, email, address);
				Map<String, Integer> idAccountDetailsMap = service.createAccount(customer);
				if (idAccountDetailsMap != null) {
					System.out.println();
					System.out.println("Account Created Successfully.......");
					System.out.println("Your customer ID: " + idAccountDetailsMap.get("customerId"));
					System.out.println("Your account no: " + idAccountDetailsMap.get("accountNo"));
				}

				int option2 = 0;
				do {
					System.out.println();
					System.out.println(
							"1.Show Balance\n2.Deposit\n3.Withdraw\n4.Fund Transfer\n5.Print Transaction\n6.Logout");
					System.out.print("Enter the option: ");
					try {
						option2 = scanner.nextInt();
					} catch (InputMismatchException e2) {
						System.out.println("Enter only digits");
					}
					switch (option2) {
					case 1: {
						double balance = service.showBalance(customer.getCustomerId());
						System.out.println("\nBalance: " + balance);
					}
						break;
					case 2: {
						result = false;
						System.out.print("\nEnter the amount to be deposited: ");
						double amount = 0;
						try {
							amount = scanner.nextDouble();
							if (amount <= 0) {
								throw new NegativeAmountException();
							}
						} catch (NegativeAmountException e) {
							System.out.println(e.getMessage());
						} catch (InputMismatchException e4) {
							System.out.println("Enter only digits");
						}
						result = service.deposit(customer.getCustomerId(), amount);
						if (result) {
							System.out.println();
							System.out.println("Amount added successfully...........");
						} else {
							System.out.println("Amount is not added, try again!.......");
						}
					}
						break;
					case 3: {
						result = false;
						System.out.print("\nEnter the amount to be withdrawn: ");
						double amount = 0;
						try {
							amount = scanner.nextDouble();
							if (amount <= 0) {
								throw new NegativeAmountException();
							}
						} catch (NegativeAmountException e) {
							System.out.println(e.getMessage());
						} catch (InputMismatchException e) {
							System.out.println("Enter digits only");
						}
						result = service.withdraw(customer.getCustomerId(), amount);
						if (result) {
							System.out.println();
							System.out.println("Amount withdrawal successful......");
						} else {
							System.out.println("Amount cannot be withdrawn, try again!....");
						}
					}
						break;
					case 4: {
						int toCustomerId = 0;
						System.out.println("Customer ID's");
						for (int customerIds1 : StaticDb.getCustomerIds()) {
							System.out.println(customerIds1);
						}
						do {
							result = false;
							System.out.println("Enter the customer ID to which the amount has to be transferred");
							toCustomerId = scanner.nextInt();
							result = service.validateCustomerId(toCustomerId);
							if (result == false) {
								System.out.println("Customer Id not found");
							}
						} while (result != true);
						result = false;
						System.out.println("Enter the amount to be transferred");
						double amount = 0;
						try {
							amount = scanner.nextDouble();
							if (amount <= 0) {
								throw new NegativeAmountException();
							}
						} catch (NegativeAmountException e) {
							System.out.println(e.getMessage());
						} catch (InputMismatchException e) {
							System.out.println("Enter digits only");
						}
						result = service.fundTransfer(customer.getCustomerId(), toCustomerId, amount);
						if (result) {
							System.out.println();
							System.out.println("Fund Transfer Successful.......");
						} else {
							System.out.println("Fund Transfer not successfull, try again....");
						}
					}
						break;
					case 5: {
						List<Transaction> transactions = service.printTransaction();
						for (Transaction transaction : transactions) {
							if (transaction == null) {
								System.out.println("No transactions are made in this account..");
							} else {
								System.out.println(transaction);
							}
						}
					}
					case 6: {
						option2 = 6;
					}
						break;
					default: {
						System.out.println("Enter options only from 1 to 6");
					}
						break;
					}
				} while (option2 != 6);
			}
				break;
			case 2: {
				option = 2;
			}

			default: {
				System.out.println("Enter options only 1 and 2");
			}
				break;
			}
		} while (option != 2);
		scanner.close();
		scanner2.close();
	}

}
