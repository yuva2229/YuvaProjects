package com.cg.bankwallet.dao;

import java.util.List;
import java.util.Map;

import com.cg.bankwallet.bean.Customer;
import com.cg.bankwallet.bean.Transaction;

public interface IWalletDao {
	Map<String, Integer> createAccount(Customer customer);

	double showBalance(int customerId);

	boolean deposit(int customerId, double amount);

	boolean withdraw(int customerId, double amount);

	boolean fundTransfer(int fromCustomerId, int toCustomerId, double amount);

	List<Transaction> printTransaction();

	boolean validatePhone(String phone);

	boolean validateEmail(String email);
	
	boolean validateCustomerId(int customerId);

}
