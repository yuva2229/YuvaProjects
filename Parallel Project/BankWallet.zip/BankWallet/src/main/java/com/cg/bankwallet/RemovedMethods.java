package com.cg.bankwallet;

//import java.util.Collection;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

//import com.cg.bankwallet.bean.Customer;
import com.cg.bankwallet.service.IWalletService;
import com.cg.bankwallet.service.WalletServiceImpl;
//import com.cg.bankwallet.utitility.StaticDb;

public class RemovedMethods {
	IWalletService service = new WalletServiceImpl();
	Scanner scanner = new Scanner(System.in);
	boolean result = false;
	/*
	 * { do {
	 * 
	 * System.out.print("\nEnter the password: "); String password =
	 * scanner.next().trim(); result = service.validatePassword(password); if
	 * (result == false) { System.out.
	 * println("PassWord must have lowercase,uppercase,special characters and special symbols"
	 * ); } } while (result != true); }
	 */
	

	public boolean validateLoginPassword(String password) {
		/*result = false;
		Collection<Customer> collect = StaticDb.getCustomerDetails().values();
		for (Customer customers : collect) {
			if (password.equals(customers.getPassword())) {
				result = true;
			}
		}*/
		return result;
	}
	public boolean validatePassword(String password) {
		result = false;
		String passwordRegEx = "((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,20})";
		Pattern pattern = Pattern.compile(passwordRegEx);
		Matcher matcher = pattern.matcher(password);
		if (matcher.matches()) {
			result = true;
		}
		return result;
	}
}
