package com.cg.bankwallet.bean;

import java.io.Serializable;

public class Transaction implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	int transactionId;
	String transactionType;
	String transactionDate;
	int customerId;
	int accountNo;
	String amount;

	public Transaction() {
		super();
	}

	public Transaction(int transactionId, String transactionType, String transactionDate, int customerId,
			int toAccountNo, String amount) {
		super();
		this.transactionId = transactionId;
		this.transactionType = transactionType;
		this.transactionDate = transactionDate;
		this.customerId = customerId;
		this.accountNo = toAccountNo;
		this.amount = amount;
	}

	public int getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public int getToAccountNo() {
		return accountNo;
	}

	public void setToAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "\nTransaction Id=" + transactionId + "\nTransactionType=" + transactionType + "\nTransactionDate="
				+ transactionDate + "\nCustomer Id=" + customerId + "\nAccount No=" + accountNo + "\nAmount=" + amount;
	}

}
