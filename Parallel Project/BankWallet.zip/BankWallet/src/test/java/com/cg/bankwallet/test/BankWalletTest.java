package com.cg.bankwallet.test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.cg.bankwallet.bean.Customer;
import com.cg.bankwallet.bean.Transaction;
import com.cg.bankwallet.dao.IWalletDao;
import com.cg.bankwallet.dao.WalletDaoImpl;

class BankWalletTest {
	static IWalletDao dao,dao1;
	Customer customer;
	Customer customer1;
	boolean result = false;
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		dao = new WalletDaoImpl();
		dao1 = new WalletDaoImpl();
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		dao =null;
	}

	@BeforeEach
	void setUp() throws Exception {
		customer = new Customer();
		customer1 = new Customer();
	}

	@AfterEach
	void tearDown() throws Exception {
		customer=null;
		customer1=null;
	}

	@Test
	void testCreateAccount() {
		customer.setCustomerName("yuvanesh");
		customer.setDateOfBirth("02-03-1997");
		customer.setPhone("9334209088");
		customer.setEmail("yuvanesh2296@gmail.com");
		customer.setAddress("vellore");
		Map<String,Integer> createAccountMap = new HashMap<String, Integer>();
		createAccountMap = dao.createAccount(customer);
		
		if(createAccountMap!=null) {
			result =true;
		}
		assertTrue(result==true);
	}

	@Test
	void testShowBalance() {
		result = false;
		customer.setCustomerName("yuvanesh");
		customer.setDateOfBirth("02-03-1997");
		customer.setPhone("9334209088");
		customer.setEmail("yuvanesh2296@gmail.com");
		customer.setAddress("vellore");
		dao.createAccount(customer);
		double balance =dao.showBalance(customer.getCustomerId());
		if(balance==0) {
			result =true;
		}
		assertTrue(result == true);
	}

	@Test
	void testDeposit() {
		result = false;
		customer.setCustomerName("yuvanesh");
		customer.setDateOfBirth("02-03-1997");
		customer.setPhone("9334209088");
		customer.setEmail("yuvanesh2296@gmail.com");
		customer.setAddress("vellore");
		dao.createAccount(customer);
		result=dao.deposit(customer.getCustomerId(), 10000);
		assertTrue(result==true);
	}

	@Test
	void testWithdraw() {
		result = false;
		customer.setCustomerName("yuvanesh");
		customer.setDateOfBirth("02-03-1997");
		customer.setPhone("9334209088");
		customer.setEmail("yuvanesh2296@gmail.com");
		customer.setAddress("vellore");
		dao.createAccount(customer);
		result=dao.withdraw(customer.getCustomerId(), 5000);
		assertTrue(result==true);
	}

	@Test
	void testFundTransfer() {
		result = false;
		customer.setCustomerName("yuvanesh");
		customer.setDateOfBirth("02-03-1997");
		customer.setPhone("9334209088");
		customer.setEmail("yuvanesh2296@gmail.com");
		customer.setAddress("vellore");
		customer1.setCustomerName("yuvanesh");
		customer1.setDateOfBirth("02-03-1997");
		customer1.setPhone("9334209088");
		customer1.setEmail("yuvanesh2296@gmail.com");
		customer1.setAddress("vellore");
		dao.createAccount(customer);
		dao.createAccount(customer1);
		dao.deposit(customer.getCustomerId(), 10000);
		result=dao.fundTransfer(customer.getCustomerId(),customer1.getCustomerId(), 5000);
		assertTrue(result==true);

	}

	@Test
	void testPrintTransaction() {
		result = false;
		customer.setCustomerName("yuvanesh");
		customer.setDateOfBirth("02-03-1997");
		customer.setPhone("9334209088");
		customer.setEmail("yuvanesh2296@gmail.com");
		customer.setAddress("vellore");
		customer1.setCustomerName("yuvanesh");
		customer1.setDateOfBirth("02-03-1997");
		customer1.setPhone("9334209088");
		customer1.setEmail("yuvanesh2296@gmail.com");
		customer1.setAddress("vellore");
		dao.createAccount(customer);
		dao.createAccount(customer1);
		List<Transaction> transactions = dao.printTransaction();
		
		assertEquals(3,transactions.size());
	}

	@Test
	void testValidatePhone() {
		result =false;
		String phone = "9867503214";
		result = dao.validatePhone(phone);
		assertTrue(result==true);
	}

	@Test
	void testValidateEmail() {
		result =false;
		String email = "yuvanesh2296@gmail.com";
		result = dao.validateEmail(email);
		assertTrue(result==true);
	}

	

	@Test
	void testValidateCustomerId() {
		result =false;
		customer.setCustomerName("yuvanesh");
		customer.setDateOfBirth("02-03-1997");
		customer.setPhone("9334209088");
		customer.setEmail("yuvanesh2296@gmail.com");
		customer.setAddress("vellore");
		dao.createAccount(customer);
		result = dao.validateCustomerId(customer.getCustomerId());
		assertTrue(result==true);
	}

	
}
