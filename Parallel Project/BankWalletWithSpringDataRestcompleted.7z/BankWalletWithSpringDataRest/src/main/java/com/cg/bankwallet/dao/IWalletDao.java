package com.cg.bankwallet.dao;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.bankwallet.bean.Customer;
import com.cg.bankwallet.bean.Transaction;

@Repository
@Transactional
public interface IWalletDao extends JpaRepository<Customer, Integer> {
	/*
	 * public Customer createAccount(Customer customer);
	 * 
	 * public double showBalance(int customerId);
	 * 
	 * public boolean deposit(int customerId, double amount);
	 * 
	 * public boolean withdraw(int customerId, double amount);
	 * 
	 * public boolean fundTransfer(int fromCustomerId, int toCustomerId, double
	 * amount);
	 * 
	 * public List<Transaction> printTransaction(int customerId);
	 * 
	 * public List<Integer> getCustomerIds();
	 * 
	 * public Customer validateLogin(int customerId, String password);
	 */
	@Query("select c from Customer c where c.customerId=?1  and c.password=?2")
	public Customer validateLogin(int customerId, String password);
	
	
}
