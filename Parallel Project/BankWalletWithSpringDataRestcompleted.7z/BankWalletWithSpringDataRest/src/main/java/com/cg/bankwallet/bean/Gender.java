package com.cg.bankwallet.bean;

import org.springframework.stereotype.Component;

@Component
public class Gender {

	private String type;

	public Gender() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Gender(String type) {
		super();
		this.type = type;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
	
}
