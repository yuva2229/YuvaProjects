package com.cg.bankwallet.bean;

import java.io.Serializable;


import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Component
@Entity
@Table(name = "transaction_details2")
public class Transaction implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_Sequence")
	@SequenceGenerator(name = "my_Sequence", sequenceName = "transaction3", initialValue = 1001, allocationSize = 1)
	@Column(length = 5, unique = true)
	private int transactionId;
	@Column(length = 15)
	private String transactionType;
	@Column(length = 30)
	private String transactionDate;
	@JsonIgnore
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "customerId")
	private Customer customer;
	@Column(length = 5)
	private int accountNo;
	@Column(length = 15, precision = 10, scale = 2)
	private String amount;

	public Transaction() {
		super();
	}

	

	public Transaction(String transactionType, String transactionDate, int accountNo, String amount) {
		super();
		this.transactionType = transactionType;
		this.transactionDate = transactionDate;
		this.accountNo = accountNo;
		this.amount = amount;
	}



	public int getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}


	public int getToAccountNo() {
		return accountNo;
	}

	public void setToAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public Customer getCustomer() {
		return customer;
	}
	
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public int getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}



	@Override
	public String toString() {
		return "\nTransaction Id = " + transactionId + "\nTransaction Type = " + transactionType
				+ "\nTransaction Date = " + transactionDate + "\nAccount No = " + accountNo + "\nAmount = " + amount ;
	}

	

}
