package com.cg.bankwallet.service;

import java.util.List;


import com.cg.bankwallet.bean.Customer;
import com.cg.bankwallet.bean.Transaction;

public interface IWalletService {
	public Customer createAccount(Customer customer);

	public double showBalance(int customerId);

	public boolean deposit(int customerId, double amount);

	public boolean withdraw(int customerId, double amount);

	public boolean fundTransfer(int fromCustomerId, int toCustomerId, double amount);

	public List<Transaction> printTransaction(int customerId);
	
	public List<Integer> getCustomerIds();
	
	public Customer validateLogin(int customerId, String password);
	
	public Customer getCustomerById(int customerId);

}
