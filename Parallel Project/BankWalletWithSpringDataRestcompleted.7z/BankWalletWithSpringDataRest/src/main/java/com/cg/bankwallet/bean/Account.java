package com.cg.bankwallet.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.stereotype.Component;
@Component
@Entity
@Table(name = "account_details2")
public class Account implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy =GenerationType.SEQUENCE,generator =  "mySequence")
	@SequenceGenerator(name =  "mySequence", sequenceName =  "account3", initialValue =  6250, allocationSize =  1)
	@Column(length = 5, unique = true)
	private int accountNo;
	@Column(length = 15, precision = 10, scale = 2)
	private double balance;

	public Account() {
		super();
	}

	
	public Account(double balance) {
		super();
		this.balance = balance;
	}


	public int getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "accountNo=" + accountNo + ", balance=" + balance;
	}

}
