package com.cg.bankwallet.restcontroller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.cg.bankwallet.bean.Customer;
import com.cg.bankwallet.bean.Gender;
import com.cg.bankwallet.bean.Transaction;
import com.cg.bankwallet.service.IWalletService;


@RestController
public class BankWalletRestController {
	@Autowired
	Customer customer;
	
	@Autowired
	IWalletService iWalletService;
	
	boolean result;
	
	@RequestMapping("/")
	public ModelAndView homePage() {
		ModelAndView view = new ModelAndView();
		view.setViewName("login");
		return view;
	}
	
	@RequestMapping(value = "/loginvalidation", method = RequestMethod.POST)
	public ModelAndView validate(@RequestParam Integer customerId, @RequestParam String password, HttpServletRequest request) {
		ModelAndView view = new ModelAndView();
		HttpSession session = request.getSession();
		customer = iWalletService.validateLogin(customerId, password);
		if(customer!=null) {
			session.setAttribute("customer", customer);
			view.addObject("customerId", customer.getCustomerId());
			view.addObject("accountNo", customer.getAccount().getAccountNo());
			view.setViewName("home");
		}
		else {
			view.addObject("status", "Invalid ID and password");
			view.setViewName("login");
		}
		return view;
	}
	
	@ModelAttribute("genderList")
	public List<Gender> populate() {
		ArrayList<Gender> list = new ArrayList<Gender>();
		Gender gender = new Gender();
		gender.setType("Male");
		Gender gender2 = new Gender();
		gender2.setType("Female");
		list.add(gender);
		list.add(gender2);
		return list;
	}
	
	@RequestMapping("createAccountLink")
	public String createAccount(ModelMap map) {
		map.addAttribute(customer);
		return "register";
	}
	
	/*@RequestMapping("/create")
	public ModelAndView register(@ModelAttribute Customer customer, BindingResult result,HttpServletRequest request) {
		ModelAndView view = new ModelAndView();
		HttpSession session = request.getSession();
		if(result.hasErrors()) {
			view.addObject("status", "Registration not successful! Try again");
			view.setViewName("register");
		}
		else {
			customer=iWalletService.createAccount(customer);
			session.setAttribute("customer", customer);
			view.addObject("customerId", customer.getCustomerId());
			view.addObject("accountNo", customer.getAccount().getAccountNo());
			view.setViewName("home");
		}
		return view; 
	}*/
	
	@PostMapping("/create/{name}/{dateOfBirth}/{phone}/{gender}/{age}/{password}/{email}/{address}")
	public Customer register(@PathVariable String name, @PathVariable String dateOfBirth, @PathVariable String phone, @PathVariable String gender, @PathVariable Integer age, @PathVariable String password, @PathVariable String email, @PathVariable String address) {
			customer.setCustomerName(name);
			customer.setDateOfBirth(dateOfBirth);
			customer.setPhone(phone);
			customer.setGender(gender);
			customer.setAge(age);
			customer.setPassword(password);
			customer.setEmail(email);
			customer.setAddress(address);
			Customer savedCustomer=iWalletService.createAccount(customer);
		return  savedCustomer;
	}
	
	
	@PutMapping("/deposit/{customerId}/{amount}")
	public Boolean deposit(@PathVariable Integer customerId,@PathVariable Double amount) {
		result = false;
		result = iWalletService.deposit(customerId, amount);
		return result;
	}
	
	@PutMapping("/withdraw/{customerId}/{amount}")
	public boolean withdraw(@PathVariable Integer customerId,@PathVariable Double amount) {
		result = false; 
		result = iWalletService.withdraw(customerId, amount);
		return result;
	}
	
	@PutMapping("/fundtransfer/{fromCustomerId}/{toCustomerId}/{amount}")
	public List<Customer> fundTransfer(@PathVariable Integer fromCustomerId, @PathVariable Integer toCustomerId, @PathVariable Double amount ) {
		iWalletService.fundTransfer(fromCustomerId, toCustomerId, amount);
		Customer fromCustomer = iWalletService.getCustomerById(fromCustomerId);
		Customer toCustomer = iWalletService.getCustomerById(toCustomerId);
		List<Customer> customers = new ArrayList<Customer>();
		customers.add(fromCustomer);
		customers.add(toCustomer);
		return customers;
	}
	
	@GetMapping("/printtransactions/{customerId}")
	public List<Transaction> printTransactions(@PathVariable Integer customerId) {
		return iWalletService.printTransaction(customerId);
	}
	
	@GetMapping("/showbalance/{customerId}")
	public Double showBalanceRest(@PathVariable Integer customerId) {
		double balance = iWalletService.showBalance(customerId);
		return balance;
	}
	
	@RequestMapping("/showbalancelink")
	public ModelAndView showBalance(HttpServletRequest request) {
		ModelAndView view = new ModelAndView();
		customer = (Customer)request.getSession().getAttribute("customer");
		double balance = iWalletService.showBalance(customer.getCustomerId());
		view.addObject("balance", balance);
		view.setViewName("showbalance");
		return view;
	}
	
	@RequestMapping("/homelink")
	public ModelAndView home(HttpServletRequest request) {
		ModelAndView view = new ModelAndView();
		customer = (Customer)request.getSession().getAttribute("customer");
		view.addObject("customerId", customer.getCustomerId());
		view.addObject("accountNo", customer.getAccount().getAccountNo());
		view.setViewName("home");
		return view;
	}
	
	@RequestMapping("/home") 
	public ModelAndView homepage(HttpServletRequest request) {
		ModelAndView view = new ModelAndView();
		customer = (Customer)request.getSession().getAttribute("customer");
		view.addObject("customerId", customer.getCustomerId());
		view.addObject("accountNo", customer.getAccount().getAccountNo());
		view.setViewName("home");
		return view;
	}
	
	@RequestMapping("/depositlink")
	public String depositLink(ModelMap map,HttpServletRequest request) {
		customer = (Customer) request.getSession().getAttribute("customer");
		map.addAttribute(customer);
		return "deposit";
	}
	
	@RequestMapping("/desit") 
	public ModelAndView deposit(@RequestParam Double amount, HttpServletRequest  request) {
		ModelAndView view = new ModelAndView();
		customer = (Customer) request.getSession().getAttribute("customer");
		boolean result = iWalletService.deposit(customer.getCustomerId(), amount);
		if(result) {
			view.addObject("status", "Deposit Successful");
			view.addObject("customerId", customer.getCustomerId());
			view.addObject("accountNo", customer.getAccount().getAccountNo());
			view.setViewName("home");
		}
		else {
			view.addObject("status", "Deposit unsuccessful");
			view.addObject("customerId", customer.getCustomerId());
			view.addObject("accountNo", customer.getAccount().getAccountNo());
			view.setViewName("home");
		}
		
		return view;
	}
	
	@RequestMapping("/withdrawlink")
	public String withdrawLink() {
		return "withdraw";
	}
	
	@RequestMapping("/wdraw") 
	public ModelAndView withdraw(@RequestParam Double amount, HttpServletRequest  request) {
		ModelAndView view = new ModelAndView();
		customer = (Customer) request.getSession().getAttribute("customer");
		boolean result = iWalletService.withdraw(customer.getCustomerId(), amount);
		if(result) {
			view.addObject("status", "Withdraw Successful");
			view.addObject("customerId", customer.getCustomerId());
			view.addObject("accountNo", customer.getAccount().getAccountNo());
			view.setViewName("home");
		}
		else {
			view.addObject("status", "Withdraw unsuccessful");
			view.addObject("customerId", customer.getCustomerId());
			view.addObject("accountNo", customer.getAccount().getAccountNo());
			view.setViewName("home");
		}
		
		return view;
	}
	
	@RequestMapping("/fundtransferlink")
	public ModelAndView fundTransferLink() {
		ModelAndView view = new ModelAndView();
		List<Integer> customerIds = iWalletService.getCustomerIds();
		view.addObject("customerIds",customerIds);
		view.setViewName("fundtransfer");
		return view;
	}
	
	@RequestMapping("/ftransfer")
	public ModelAndView fundTransfer(@RequestParam Integer customerId,@RequestParam Double amount, HttpServletRequest request) {
		ModelAndView view = new ModelAndView();
		customer = (Customer) request.getSession().getAttribute("customer");
		boolean result = iWalletService.fundTransfer(customer.getCustomerId(), customerId, amount);
		if(result) {
			view.addObject("status", "Fund Transfer Successful");
			view.addObject("customerId", customer.getCustomerId());
			view.addObject("accountNo", customer.getAccount().getAccountNo());
			view.setViewName("home");
		}
		else {
			view.addObject("status", "Fund Transfer Unsuccessful");
			view.addObject("customerId", customer.getCustomerId());
			view.addObject("accountNo", customer.getAccount().getAccountNo());
			view.setViewName("home");
		}
		return view;
	}
	
	@RequestMapping("/printtransactionlink")
	public ModelAndView printTransactions(HttpServletRequest request) {
		ModelAndView view = new ModelAndView();
		customer = (Customer) request.getSession().getAttribute("customer");
		List<Transaction> transactions= iWalletService.printTransaction(customer.getCustomerId());
		view.addObject("transactions",transactions);
		view.setViewName("printtransactions");
		return view;
	}
	
	@RequestMapping("/logoutlink")
	public ModelAndView logout(HttpServletRequest request) {
		ModelAndView view = new ModelAndView();
		request.getSession().invalidate();
		view.setViewName("login");
		return view;
	}
}
