package com.cg.bankwallet.service;

import java.text.DateFormat;


import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bankwallet.bean.Account;
import com.cg.bankwallet.bean.Customer;
import com.cg.bankwallet.bean.Transaction;
import com.cg.bankwallet.dao.IWalletDao;
import com.cg.bankwallet.exception.ZeroBalanceException;

@Service
public class WalletServiceImpl implements IWalletService {

	List<Transaction> transactions = new ArrayList<Transaction>();
	List<Transaction> transactions2 = new ArrayList<Transaction>();
	@Autowired
	Account account;

	@Autowired
	Transaction transaction;
	
	@Autowired
	Transaction transaction2;

	@Autowired
	IWalletDao iWalletDao;


	boolean result = false;

	@Override
	public Customer createAccount(Customer customer) {
		iWalletDao.save(customer);
		account.setBalance(0);
		customer.setAccount(account);
		return iWalletDao.save(customer);
	}

	@Override
	public double showBalance(int customerId) {
		Customer customer = iWalletDao.findById(customerId).get();
		return customer.getAccount().getBalance();
	}

	@Override
	public boolean deposit(int customerId, double amount) {
		result = false;
		Customer customer = iWalletDao.findById(customerId).get();
		double balance = showBalance(customerId);
		double preBalance = balance;
		balance = balance + amount;
		customer.getAccount().setBalance(balance);
		iWalletDao.save(customer);
		if (preBalance < showBalance(customerId)) {
			result = true;
			int toAccount = customer.getAccount().getAccountNo();
			Date date = Calendar.getInstance().getTime();
			DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");
			String strDate = dateFormat.format(date);
			transaction.setTransactionType("Deposit");
			transaction.setTransactionDate(strDate);
			transaction.setToAccountNo(toAccount);
			transaction.setAmount(Double.toString(amount));
			transaction.setCustomer(customer);
			transactions = customer.getTransactions();
			transactions.add(transaction);
			customer.setTransactions(transactions);
			iWalletDao.save(customer);
		}
		return result;
	}

	@Override
	public boolean withdraw(int customerId, double amount) {
		result = false;
		Customer customer = iWalletDao.findById(customerId).get();
		double balance = 0;
		try {
			balance = showBalance(customerId);
			if(balance==0) {
				throw new ZeroBalanceException();
			}
		} catch (ZeroBalanceException e) {
			e.getMessage();
		}
		if (balance != 0) {
			double preBalance = balance;
			balance = balance - amount;
			customer.getAccount().setBalance(balance);
			iWalletDao.save(customer);
			if (preBalance > showBalance(customerId)) {
				result = true;
				int toAccount = customer.getAccount().getAccountNo();
				Date date = Calendar.getInstance().getTime();
				DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");
				String strDate = dateFormat.format(date);
				transaction.setTransactionType("Withdraw");
				transaction.setTransactionDate(strDate);
				transaction.setToAccountNo(toAccount);
				transaction.setAmount(Double.toString(amount));
				transaction.setCustomer(customer);
				transactions = customer.getTransactions();
				transactions.add(transaction);
				customer.setTransactions(transactions);
				iWalletDao.save(customer);
			}
		}
		return result;
	}

	@Override
	public boolean fundTransfer(int fromCustomerId, int toCustomerId, double amount) {
		result = false;
		Customer customer = iWalletDao.findById(fromCustomerId).get();
		Customer customer2 = iWalletDao.findById(toCustomerId).get();
		double withdrawBalance = 0;
		try {
			withdrawBalance = showBalance(fromCustomerId);
			if(withdrawBalance==0) {
				throw new ZeroBalanceException();
			}
		} catch (ZeroBalanceException e) {
			e.getMessage();
		}
		double transferBalance = showBalance(toCustomerId);
		if (withdrawBalance != 0) {
			double withdrawPreBalance = withdrawBalance;
			double transferPreBalance = transferBalance;
			withdrawBalance = withdrawBalance - amount;
			customer.getAccount().setBalance(withdrawBalance);
			iWalletDao.save(customer);
			transferBalance = transferBalance + amount;
			customer2.getAccount().setBalance(transferBalance);
			iWalletDao.save(customer2);
			if (transferPreBalance < showBalance(toCustomerId) && withdrawPreBalance > showBalance(fromCustomerId)) {
				result = true;
				int fromAccount = customer.getAccount().getAccountNo();
				Date date = Calendar.getInstance().getTime();
				DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");
				String strDate = dateFormat.format(date);
				transaction.setTransactionType("Fund Transfer");
				transaction.setTransactionDate(strDate);
				transaction.setToAccountNo(customer2.getAccount().getAccountNo());
				transaction.setAmount(Double.toString(amount));
				transaction.setCustomer(customer);
				transactions = customer.getTransactions();
				transactions.add(transaction);
				customer.setTransactions(transactions);
				iWalletDao.save(customer);
				transaction2.setTransactionType("Fund Transfer");
				transaction2.setTransactionDate(strDate);
				transaction2.setToAccountNo(fromAccount);
				transaction2.setAmount(Double.toString(amount));
				transaction2.setCustomer(customer2);
				transactions2 = customer2.getTransactions();
				transactions2.add(transaction2);
				customer2.setTransactions(transactions2);
				iWalletDao.save(customer2);
			}

		}
		return result;

	}

	@Override
	public List<Transaction> printTransaction(int customerId) {
		Optional<Customer> cust = iWalletDao.findById(customerId);
		Customer customer=cust.get();
		System.out.println(customer);
		transactions=customer.getTransactions();
	
		return transactions;
	}

	@Override
	public List<Integer> getCustomerIds() {
		List<Customer> customers = iWalletDao.findAll(); 
		List<Integer> customerIds = new ArrayList<Integer>();
		for(Customer customer:customers) {
			customerIds.add(customer.getCustomerId());
		}
		return customerIds;
	}

	@Override
	public Customer validateLogin(int customerId, String password) {
		return iWalletDao.validateLogin(customerId, password);
	}

	@Override
	public Customer getCustomerById(int customerId) {
		Customer customer = iWalletDao.findById(customerId).get();
		return customer;
	}

}
