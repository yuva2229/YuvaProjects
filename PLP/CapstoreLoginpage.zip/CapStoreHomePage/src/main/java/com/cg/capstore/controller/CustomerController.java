package com.cg.capstore.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.capstore.service.CustomerService;
import com.cg.capstore.service.MerchantService;

@Controller("customerController")
public class CustomerController {
	@Autowired
	CustomerService customerService;
	
	
	@RequestMapping("/customerRegister")
	public String register() {
		return "customerRegister";
	}
	
	
	@RequestMapping("/savecustomer")
	public String addProduct(HttpServletRequest request) {
		String firstname = request.getParameter("fn");
		String lastname = request.getParameter("ln");
		String phoneno = request.getParameter("phoneno");
		String emailId = request.getParameter("email");
		String password = request.getParameter("password");
	
		customerService.createAccount(firstname, lastname, phoneno, emailId, password);
		return "home";
	}
	
	
}
