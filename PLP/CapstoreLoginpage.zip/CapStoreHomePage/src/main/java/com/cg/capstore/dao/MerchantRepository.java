package com.cg.capstore.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.capstore.dto.Merchant;

@Repository("merchantRepository")
public interface MerchantRepository extends JpaRepository<Merchant, String> {

	Merchant findByMerchantEmail(String merchantEmail);
	
	
}
