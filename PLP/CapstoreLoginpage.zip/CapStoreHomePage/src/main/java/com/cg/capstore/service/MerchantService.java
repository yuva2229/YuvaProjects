package com.cg.capstore.service;

import com.cg.capstore.dto.Merchant;

public interface MerchantService {
	public Merchant createMerchantAccount(String merchantname,String MerchantEmail,String password,String Companyname,String CompanyAddress,String phone_no,String merchantType,int flag, String rating);
	Merchant findByMerchantEmail(String MerchantEmail);
}
