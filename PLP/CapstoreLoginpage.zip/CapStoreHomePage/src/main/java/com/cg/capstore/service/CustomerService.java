package com.cg.capstore.service;

import com.cg.capstore.dto.Customer;

public interface CustomerService {
	public Customer createAccount(String firstName,String lastName,String phoneNo,String emailId,String password);
	Customer findByEmailId(String emailId);
}
