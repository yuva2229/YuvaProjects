package com.cg.capstore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.capstore.dao.MerchantRepository;
import com.cg.capstore.dto.Merchant;
@Service("merchantService")
public class MerchantServiceImpl implements MerchantService{
	@Autowired
	MerchantRepository merchantRepository;
	@Override
	public Merchant createMerchantAccount(String merchantname, String MerchantEmail,String password ,String Companyname,
			String CompanyAddress, String phone_no,String merchantType,int flag, String rating) {
		
		Merchant m=new Merchant(merchantname, MerchantEmail, password, Companyname,CompanyAddress, phone_no, merchantType,0,"");
		merchantRepository.save(m);
		return m;
	}
	
	public Merchant findByMerchantEmail(String MerchantEmail) {
		return merchantRepository.findByMerchantEmail(MerchantEmail);
	}

}
