package com.capstore.boot.service;

import java.util.Base64;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstore.boot.dao.CustomerDao;
import com.capstore.boot.model.Customer;

@Service("customerService")
public class CustomerServiceImpl implements CustomerService{

	@Autowired
	CustomerDao customerDao;
	
	@Override
	public List<Customer> getAllCustomers() {
		
		return customerDao.findAll();
	}
    


	@Override
	public List<Customer> getAllCustomerEmail() {
	
		return customerDao.findAll();
	}
	@Override
    public Customer findOne(Integer customerId){
    	return customerDao.getOne(customerId);
    }
	@Override
    public List<Customer> getAllCustomer(){
    	return (List<Customer>) customerDao.findAll();
    }



	@Override
	public Customer findByEmailId(String emailId) throws NullPointerException {
	 Customer c = customerDao.findByemailId(emailId);
	 if(c==null) {
		 return c;
	 }else {
		c.setPassword(decrypt(c.getPassword()));
	 }
		return c;
	}



	@Override
	public boolean createcustomer(Customer customer) {
		
	Customer c = customerDao.findByemailId(customer.getEmailId());
	boolean status = false;
		
		if(c==null) {
			customer.setPassword(encrypt(customer.getPassword()));
			customerDao.save(customer);
			status=true;
			return status;
		}
	return status;
		
	}
	public String encrypt(String str) {
		// Getting encoder
		Base64.Encoder encoder = Base64.getEncoder();

		//encrypted String
		String ecode = encoder.encodeToString(str.getBytes());
		return ecode;
	}

	public String decrypt(String str) {
		// Getting encoder
		Base64.Decoder decoder = Base64.getDecoder();

		//encrypted String
		byte[] ecode = decoder.decode(str);
		return new String(ecode);
	}

}
