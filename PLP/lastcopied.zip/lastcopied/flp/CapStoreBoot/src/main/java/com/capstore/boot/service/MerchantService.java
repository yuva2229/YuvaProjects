package com.capstore.boot.service;

import java.util.List;

import com.capstore.boot.model.Inventory;
import com.capstore.boot.model.Merchant;



public interface MerchantService {
	
	public List<Merchant> getAllMerchant();
	
	public Merchant findMerchantById(Integer merchantId);
	public boolean saveMerchant(Merchant merchant);
	public void deleteMerchant(Integer merchantId);
	
	public List<Merchant> getAllMerchant1();
	
	public Merchant findByMerchantEmail(String emailId);
	
	public List<Inventory> findBymerchantId(int id);
	
}
