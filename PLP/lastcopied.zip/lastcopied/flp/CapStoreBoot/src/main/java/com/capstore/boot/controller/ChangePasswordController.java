package com.capstore.boot.controller;

import java.util.Base64;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.capstore.boot.model.Customer;
import com.capstore.boot.model.Inventory;
import com.capstore.boot.service.IPasswordService;
import com.capstore.boot.service.InventoryService;



@Controller
public class ChangePasswordController {

	@Autowired
	IPasswordService passwordService;

	@Autowired
	InventoryService inventoryService;
	
	
	@RequestMapping("changepassword")
	public String openchangepassword() {
		return "changepassword";
	}
	
	@RequestMapping("change")
	public ModelAndView changepassword(HttpServletRequest request) {
		
		ModelAndView view = new ModelAndView();
		

		String old = request.getParameter("oldpass");
		String newpass = request.getParameter("newpass");
		String confnew = request.getParameter("confnewpass");
		
		HttpSession session = request.getSession();
      Customer c = (Customer)session.getAttribute("user");
      
     
     
     if(old.equals(c.getPassword())) {
    	 
    	 if(newpass.equals(confnew)) {
    		 
    		 passwordService.changecustomerPassword(c, newpass);
    		 session.invalidate();
    		 session = request.getSession();
    			
    			List<Inventory> productlist = inventoryService.getAll();
    			
    			view.addObject("plist", productlist);
    			
    			session.setAttribute("prodlist", productlist);
    		 view.setViewName("home");
    		 
    	 }else {
    		 view.addObject("msg", "new password & confirm password not matched!!");
        	 view.setViewName("changepassword");
    	 }
    	 
     }else {
    	 view.addObject("msg", "old password not matched!!");
    	 view.setViewName("changepassword");
     }
		
		return view;
	}
	
	public String decrypt(String str) {
		// Getting encoder
		Base64.Decoder decoder = Base64.getDecoder();

		//encrypted String
		byte[] ecode = decoder.decode(str);
		String spa=new String(ecode);
		return spa;
	}
	
}




