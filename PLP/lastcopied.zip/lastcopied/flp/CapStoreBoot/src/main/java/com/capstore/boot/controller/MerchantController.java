package com.capstore.boot.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capstore.boot.model.Address;
import com.capstore.boot.model.Inventory;
import com.capstore.boot.model.Merchant;
import com.capstore.boot.service.InventoryService;
import com.capstore.boot.service.MerchantService;

@Controller
public class MerchantController {

	@Autowired
	MerchantService merchantService;

	@Autowired
	InventoryService inventoryService;

	@RequestMapping("/registerasmerchant")
	public String register() {
		return "merchantRegisterform";
	}

	@RequestMapping("/saveasmerchant")
	public ModelAndView addProduct(HttpServletRequest request) {

		ModelAndView modelView = new ModelAndView();

		Merchant merchant = new Merchant();
		Address address = new Address();

		String MerchantName = request.getParameter("mn");
		merchant.setMerchantname(MerchantName);

		String email = request.getParameter("memail");
		merchant.setEmailId(email);

		String password = request.getParameter("mpass");
		merchant.setPassword(password);

		String companyname = request.getParameter("cn");
		merchant.setCompanyName(companyname);

		String companyaddress = request.getParameter("ca");
		address.setZipcode(500072);
		address.setStreetNumber(12);
		List<Address> list1 = Arrays.asList(address);
		merchant.setAddress(list1);

		String phoneno = request.getParameter("pn");
		merchant.setPhoneNo(phoneno);

		String merchanttype = request.getParameter("mt");
		merchant.setIsCertified(merchanttype);

		boolean status = merchantService.saveMerchant(merchant);

		if (status == true) {

			modelView.setViewName("home");
		} else {
			modelView.addObject("msg", "Merchant with this Email already exists!!");
			modelView.setViewName("merchantRegisterform");
		}

		return modelView;
	}

	@RequestMapping("/showAllProduct")
	public ModelAndView showAllProductsaddedBymerchant(HttpServletRequest request) {

		ModelAndView modelView = new ModelAndView();

		HttpSession session = request.getSession();

		Merchant merchant = (Merchant) session.getAttribute("user");

		// List<Inventory> list =
		// merchantService.findBymerchantId(merchant.getMerchantId());

		List<Inventory> list = merchant.getInventory();
		System.out.println(merchant);
		System.out.println(list);
		// modelView.addObject("pList", list);
		session.setAttribute("productslist", list);
		System.out.println(list);
		modelView.setViewName("merchantaddedproducts");
		return modelView;
	}

}
