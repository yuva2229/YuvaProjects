package com.capstore.boot.service;

import java.util.List;

import com.capstore.boot.model.FeedBack;


public interface IFeedbackService 
{

	public FeedBack givefeedback(String comments,int rate, int cid, int pid, int mid);

	public List<FeedBack> getAll(int pid);

	public double avgrating(int pid);

	public double merchantrating(int mid);

}
