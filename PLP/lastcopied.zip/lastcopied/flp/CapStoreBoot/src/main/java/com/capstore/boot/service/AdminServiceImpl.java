package com.capstore.boot.service;


import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstore.boot.dao.AdminDao;
import com.capstore.boot.model.Admin;

@Service("adminService")
public class AdminServiceImpl implements AdminService{

	@Autowired
	 AdminDao adminDao;

	@Override
	public List<Admin> getAdminEmail() {
		return adminDao.findAll();
	}

	


}
