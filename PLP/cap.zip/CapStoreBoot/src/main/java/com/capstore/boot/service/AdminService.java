package com.capstore.boot.service;

import java.util.List;

import com.capstore.boot.model.Admin;



public interface AdminService {

	public List<Admin> getAdminEmail();
}
