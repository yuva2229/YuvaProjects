package com.capstore.boot.service;

import java.util.List;

import com.capstore.boot.model.Brand;
import com.capstore.boot.model.Category;
import com.capstore.boot.model.Inventory;



public interface InventoryService {

	public void save1(Inventory product);
	public void save(Brand br);
	public void save2(Category cg);
    public void delete(Integer productId) ;
    
    public List<Inventory> getInventoryByName(String inventoryName);
    
    public List<Inventory> getAll();
	List<Inventory> getAllInventory();
	public List<Brand> getAllBrands();
	public List<Category> getAllCategories();
}
