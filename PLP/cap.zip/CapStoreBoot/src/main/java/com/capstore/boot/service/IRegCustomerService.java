package com.capstore.boot.service;

import java.util.List;

import com.capstore.boot.model.Customer;




public interface IRegCustomerService {
	public void saveCustomer(Customer customer);
	public List<Customer> getAllCustomers();
	public Customer getValidCustomer(String username, String password);
	
}
