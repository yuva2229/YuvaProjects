package com.capstore.boot.service;

import java.util.List;

import com.capstore.boot.model.Customer;



public interface IPasswordService {

	public List<Customer> getAllCustomers();

}
