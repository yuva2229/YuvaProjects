package com.capstore.boot.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class AdminController {

	
	@RequestMapping("index")
	public String sd() {
		return null;
		
	
	
	}
}
	
	
	
	
