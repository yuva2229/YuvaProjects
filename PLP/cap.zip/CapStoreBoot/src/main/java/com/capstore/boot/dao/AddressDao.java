package com.capstore.boot.dao;




import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capstore.boot.model.Address;

@Repository("addressDao")
public interface AddressDao extends JpaRepository<Address, Integer>{

}
