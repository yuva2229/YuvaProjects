package com.capstore.boot.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstore.boot.dao.BrandDao;
import com.capstore.boot.dao.ICategoryDao;
import com.capstore.boot.dao.InventoryDao;
import com.capstore.boot.model.Brand;
import com.capstore.boot.model.Category;
import com.capstore.boot.model.Inventory;

@Service("inventoryService")
@Transactional
public class InventoryServiceImpl implements InventoryService {
	@Autowired
    InventoryDao inventoryDao;
	
	@Autowired
	private BrandDao brandDao;
	
	@Autowired
	private ICategoryDao categoryDao;
	
	@Override
    public List<Inventory> getAllInventory(){
    	return (List<Inventory>) inventoryDao.findAll();
    }

	@Override
	public void save1(Inventory product) {
		inventoryDao.save(product);
	}
	
	@Override
	public void delete(Integer productId) {
		// TODO Auto-generated method stub
		inventoryDao.deleteById(productId);
	}

	@Override
	public List<Inventory> getAll() {
		// TODO Auto-generated method stub
		return inventoryDao.findAll();
	}

		@Override
	public List<Brand> getAllBrands() {
		// TODO Auto-generated method stub
		return brandDao.findAll();
	}

	@Override
	public List<Category> getAllCategories() {
		
		return categoryDao.findAll();
	}

	@Override
	public void save(Brand br) {
		brandDao.save(br);
		
	}

	@Override
	public void save2(Category cg) {
		categoryDao.save(cg);
		
	}

	@Override
	public List<Inventory> getInventoryByName(String inventoryName) {
		// TODO Auto-generated method stub
		
		return inventoryDao.findByproductName(inventoryName);
	}

	
/*
	

	@Override
	public Inventory findProduct(Integer productId) {
		// TODO Auto-generated method stub
	 inventoryDao.find(productId);
	}*/
	
	
	
	
}
