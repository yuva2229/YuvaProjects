package com.capstore.boot.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.websocket.Session;

import org.hibernate.query.criteria.internal.predicate.BetweenPredicate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capstore.boot.model.Inventory;
import com.capstore.boot.service.InventoryService;


@Controller
public class CapStoreController 
{
	@Autowired
	InventoryService inventoryService;
	
	@RequestMapping(value="all")
	public String start()
	{
		return "home";
		
	}
	

	@RequestMapping(value="login")
	public ModelAndView showlogin(Model model){
		return new ModelAndView("login");
	}
	
	
	@RequestMapping(value="/")
	public ModelAndView home(HttpServletRequest request) {
		ModelAndView modelView = new ModelAndView();
		
		HttpSession session = request.getSession();
		
		List<Inventory> productlist = inventoryService.getAll();
		
		modelView.addObject("plist", productlist);
		
		session.setAttribute("prodlist", productlist);
		
		System.out.println(productlist);
		
		modelView.setViewName("index");
		return modelView;
	}
	
/*	@RequestMapping(value="products")
	public ModelAndView Categories(@ModelAttribute("my") Inventory s, @RequestParam("id") int i)
	{
		List<Inventory> list = inventoryService.getAllInventory(i);
		
		return new ModelAndView("categories","data",list);
		
	}*/
	
	
	
	@RequestMapping(value="/search")
	public ModelAndView search(HttpServletRequest request , @RequestParam("sss") String name) {
		
		ModelAndView modelView = new ModelAndView();
		HttpSession session = request.getSession();
		
		
		
		List<Inventory> productlist = inventoryService.getInventoryByName(name);
		
		session.setAttribute("prodlist", productlist);

		modelView.setViewName("index");
		return modelView;
	}
	
	@RequestMapping(value="/str")
	public ModelAndView sort(HttpServletRequest request , @RequestParam("p") String option) {
		
		ModelAndView modelView = new ModelAndView();
		HttpSession session = request.getSession();
		
		List<Inventory> list =  (List<Inventory>) session.getAttribute("prodlist");
	
		if(option.equals("noofviews")) {
			Comparator<Inventory> comp  = (i1, i2) -> Double.compare(i2.getNoOfViews(),i1.getNoOfViews());
			Collections.sort(list , comp);
		}else if(option.equals("lowtohigh")){
			Comparator<Inventory> comp  = (i1, i2) -> Double.compare(i1.getPrice(),i2.getPrice());
			Collections.sort(list , comp);
		}else{
			Comparator<Inventory> comp  = (i1, i2) -> Double.compare(i2.getPrice(),i1.getPrice());
			Collections.sort(list , comp);
		}
		
		modelView.setViewName("index");
		return modelView;
	}
	
	
	   @RequestMapping(value="/sortbyrange")
		public ModelAndView sort(HttpServletRequest request) {
			ModelAndView modelView = new ModelAndView();
			HttpSession session = request.getSession();
			List<Inventory> list =  (List<Inventory>) session.getAttribute("prodlist");
			
			List<Inventory> priceRangeList = new ArrayList<>();
			
			 double min = Double.parseDouble(request.getParameter("min"));
			 double max = Double.parseDouble(request.getParameter("max"));
			
			 for(Inventory i : list) {

					if( ( (i.getPrice()) >= min) && ((i.getPrice()) <= max) ) {
						priceRangeList.add(i);
					}
				}
			session.setAttribute("prodlist", priceRangeList);

			modelView.setViewName("index");
			
			return modelView;
		}
	  
	
	
     @RequestMapping("/productdisplay")
 	public ModelAndView productDisplay(HttpServletRequest request,@RequestParam("p") int pid) {
    	 
     
			ModelAndView modelView = new ModelAndView();
			HttpSession session = request.getSession();
			
			return modelView;
     }
 }
	
	
	
	


