package com.capstore.boot.controller;

import org.springframework.stereotype.Controller;

@Controller
public class CustomerController {

	
}
