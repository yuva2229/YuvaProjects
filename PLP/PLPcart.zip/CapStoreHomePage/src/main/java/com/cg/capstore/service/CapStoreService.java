package com.cg.capstore.service;

import java.util.List;

import com.cg.capstore.dto.Store;




public interface CapStoreService 
{
	List<Store> getAllProducts(Integer cat);
	//public List<Store> showAllElectronics();

	List<Store> getAll();

	public List<Store> getProductByName(String name);
	 Store findByProductId(Integer productId);
}
